import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './include/navbar/navbar.component';
import { FooterComponent } from './include/footer/footer.component';
import { LoginComponent } from './pages/login/login.component';
import { RegisterComponent } from './pages/register/register.component';
import { UserprofileComponent } from './pages/userprofile/userprofile.component';
import { FashionComponent } from './pages/fashion/fashion.component';
import { SearchComponent } from './pages/search/search.component';
import { NotfoundComponent } from './pages/notfound/notfound.component';
import { HomeComponent } from './pages/home/home.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CustpipePipe } from './pipe/custpipe.pipe';
import { ApiserviceService } from './service/apiservice.service';
//import { SentenceCasePipe } from './pipes/custpipi.pipe';
@NgModule({
  declarations: [
    //SentenceCasePipe,
    AppComponent,
    NavbarComponent,
    FooterComponent,
    LoginComponent,
    RegisterComponent,
    UserprofileComponent,
    FashionComponent,
    SearchComponent,
    NotfoundComponent,
    HomeComponent,
    CustpipePipe,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  providers: [ApiserviceService],
  bootstrap: [AppComponent],
})
export class AppModule {}
