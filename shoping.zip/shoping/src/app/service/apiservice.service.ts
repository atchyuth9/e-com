import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class ApiserviceService {
  constructor(private http: HttpClient) {}

  Getuserprofiles(): Observable<string[]> {
    return this.http.get<string[]>(
      'https://gist.githubusercontent.com/thenaveensaggam/6476ae426cd08e3ee8854a2bf1338a1e/raw/cd59ee3eb7ca2715606ba3f623ee165a4d0931c1'
    );
  }

  GetProducts(): Observable<any[]> {
    return this.http.get<any[]>('http://fakestoreapi.com/products');
  }
}
