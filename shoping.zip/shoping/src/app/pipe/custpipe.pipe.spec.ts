import { CustpipePipe } from './custpipe.pipe';

describe('CustpipePipe', () => {
  it('create an instance', () => {
    const pipe = new CustpipePipe();
    expect(pipe).toBeTruthy();
  });
});
