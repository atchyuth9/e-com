import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  constructor(private fb: FormBuilder) {}
  registrationForm!: FormGroup;
  ngOnInit(): void {
    this.registrationForm = this.fb.group({
      FirstName: ['', [Validators.required, Validators.minLength(6)]],
      LastName: ['', [Validators.required, Validators.pattern(/\w{4,10}/)]],
      Email: ['', [Validators.required, Validators.email]],
      Mobile: [
        '',
        [
          Validators.required,
          Validators.pattern('^[0-9]*$'),
          Validators.minLength(10),
          Validators.maxLength(10),
        ],
      ],
      DateOfBirth: ['', [Validators.required]],
      Password: ['', [Validators.required, Validators.maxLength(8)]],
    });
  }
  signupForm() {
    alert('form is submiited');
  }
}
