import { Component, OnInit } from '@angular/core';
import { ApiserviceService } from '../../service/apiservice.service';
@Component({
  selector: 'app-fashion',
  templateUrl: './fashion.component.html',
  styleUrls: ['./fashion.component.css'],
})
export class FashionComponent implements OnInit {
  constructor(private api: ApiserviceService) {}
  Products: any[] = [];
  ngOnInit(): void {
    this.api.GetProducts().subscribe((data) => (this.Products = data));
  }
}
