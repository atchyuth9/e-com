import { Component, OnInit } from '@angular/core';
import { ApiserviceService } from '../../service/apiservice.service';
@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css'],
})
export class UserprofileComponent implements OnInit {
  constructor(private api: ApiserviceService) {}
  Userinfo: any[] = [];
  ngOnInit(): void {
    this.api.Getuserprofiles().subscribe((data) => (this.Userinfo = data));
  }
}
